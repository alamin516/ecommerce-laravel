<div :class="menu ? 'pl-64' : ''" class="text-center font-semibold text-gray-500 py-2 !mt-2 fixed bottom-0 left-0 z-[99] w-full">
    &copy; <?php echo e(date('Y')); ?> AA. All rights reserved.
</div><?php /**PATH F:\Laravel\project-name\resources\views/admin/admin-footer.blade.php ENDPATH**/ ?>