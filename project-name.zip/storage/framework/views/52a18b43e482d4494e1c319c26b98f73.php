<?php $__env->startSection('content'); ?>
    <div class="flex items-center justify-between">
        Hi! <?php if(auth()->guard()->check()): ?> 
            <?php if(Auth::check()): ?>
                <?php echo e(Auth::user()->name); ?>

            <?php endif; ?>
        <?php endif; ?>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.profile-layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\Laravel\project-name\resources\views/dashboard.blade.php ENDPATH**/ ?>