<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

    <title><?php echo e(config('app.name', 'Laravel')); ?></title>

    <!-- Fonts -->
    <link rel="preconnect" href="https://fonts.bunny.net">
    <link href="https://fonts.bunny.net/css?family=figtree:400,500,600&display=swap" rel="stylesheet" />

    <!-- Scripts -->
    <?php echo app('Illuminate\Foundation\Vite')(['resources/css/app.css', 'resources/js/app.js']); ?>
</head>
<body class="font-sans antialiased">
<?php echo $__env->make('layouts.navigation', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

 <?php $__env->slot('header', null, []); ?> 
        <h2 class="font-semibold text-xl text-gray-800 leading-tight">
            <?php echo e(__('Dashboard')); ?>

        </h2>
     <?php $__env->endSlot(); ?>

    <div class="py-12">
        <div class="max-w-7xl mx-auto sm:px-6 lg:px-8">
            <div class="bg-white overflow-hidden shadow-sm sm:rounded-lg">
                <div class="p-6 text-gray-900 flex gap-4 items-center">
                    <?php echo e(__("You're welcome!")); ?>


                    <?php if(auth()->guard()->check()): ?> 
                    <div>
                        <?php if(Auth::check()): ?>
                        <span class="text-xl font-semibold"><?php echo e(Auth::user()->name); ?></span>
                        <?php endif; ?>
                    </div>
                    <?php endif; ?>
                </div>
            </div>

            <!-- layout start -->
             <div class="flex gap-5 mt-5">
                <div class="w-[23%] p-4 bg-white  shadow-sm sm:rounded-lg">
                    <?php echo $__env->make('profile.partials.user-sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                </div>
                <div class="w-[77%] p-4 bg-white  shadow-sm sm:rounded-lg">
                    <?php echo $__env->yieldContent('content'); ?>
                </div>
             </div>
            <!-- layout end -->
        </div>
    </div>
</body>
</html>
<?php /**PATH F:\Laravel\project-name\resources\views/layouts/profilelayout.blade.php ENDPATH**/ ?>