<div class="categories-slider grid lg:grid-cols-8 md:grid-cols-6 grid-cols-2 gap-2">
    <div class="flex flex-col items-center shadow-md rounded-md p-2">
        <img src="https://img.drz.lazcdn.com/static/bd/p/c400005c29cc708bc59a23034d9f8395.jpg_80x80q80.jpg_.webp"
            alt="Sample Image" class="w-full h-24 object-contain" />
        <p class="mt-2 text-gray-700">Category 1</p>
    </div>
    <div class="flex flex-col items-center shadow-md rounded-md p-2">
        <img src="https://img.drz.lazcdn.com/static/bd/p/c400005c29cc708bc59a23034d9f8395.jpg_80x80q80.jpg_.webp"
            alt="Sample Image" class="w-full h-24 object-contain" />
        <p class="mt-2 text-gray-700">Category 2</p>
    </div>
    <div class="flex flex-col items-center shadow-md rounded-md p-2">
        <img src="https://img.drz.lazcdn.com/static/bd/p/c400005c29cc708bc59a23034d9f8395.jpg_80x80q80.jpg_.webp"
            alt="Sample Image" class="w-full h-24 object-contain" />
        <p class="mt-2 text-gray-700">Category 3</p>
    </div>
    <div class="flex flex-col items-center shadow-md rounded-md p-2">
        <img src="https://img.drz.lazcdn.com/static/bd/p/c400005c29cc708bc59a23034d9f8395.jpg_80x80q80.jpg_.webp"
            alt="Sample Image" class="w-full h-24 object-contain" />
        <p class="mt-2 text-gray-700">Category 4</p>
    </div>
    <div class="flex flex-col items-center shadow-md rounded-md p-2">
        <img src="https://img.drz.lazcdn.com/static/bd/p/c400005c29cc708bc59a23034d9f8395.jpg_80x80q80.jpg_.webp"
            alt="Sample Image" class="w-full h-24 object-contain" />
        <p class="mt-2 text-gray-700">Category 5</p>
    </div>
    <div class="flex flex-col items-center shadow-md rounded-md p-2">
        <img src="https://img.drz.lazcdn.com/static/bd/p/c400005c29cc708bc59a23034d9f8395.jpg_80x80q80.jpg_.webp"
            alt="Sample Image" class="w-full h-24 object-contain" />
        <p class="mt-2 text-gray-700">Category 6</p>
    </div>
    <div class="flex flex-col items-center shadow-md rounded-md p-2">
        <img src="https://img.drz.lazcdn.com/static/bd/p/c400005c29cc708bc59a23034d9f8395.jpg_80x80q80.jpg_.webp"
            alt="Sample Image" class="w-full h-24 object-contain" />
        <p class="mt-2 text-gray-700">Category 7</p>
    </div>
    <div class="flex flex-col items-center shadow-md rounded-md p-2">
        <img src="https://img.drz.lazcdn.com/static/bd/p/c400005c29cc708bc59a23034d9f8395.jpg_80x80q80.jpg_.webp"
            alt="Sample Image" class="w-full h-24 object-contain" />
        <p class="mt-2 text-gray-700">Category 8</p>
    </div>
    <div class="flex flex-col items-center shadow-md rounded-md p-2">
        <img src="https://img.drz.lazcdn.com/static/bd/p/c400005c29cc708bc59a23034d9f8395.jpg_80x80q80.jpg_.webp"
            alt="Sample Image" class="w-full h-24 object-contain" />
        <p class="mt-2 text-gray-700">Category 8</p>
    </div>
    <div class="flex flex-col items-center shadow-md rounded-md p-2">
        <img src="https://img.drz.lazcdn.com/static/bd/p/c400005c29cc708bc59a23034d9f8395.jpg_80x80q80.jpg_.webp"
            alt="Sample Image" class="w-full h-24 object-contain" />
        <p class="mt-2 text-gray-700">Category 8</p>
    </div>
    <div class="flex flex-col items-center shadow-md rounded-md p-2">
        <img src="https://img.drz.lazcdn.com/static/bd/p/c400005c29cc708bc59a23034d9f8395.jpg_80x80q80.jpg_.webp"
            alt="Sample Image" class="w-full h-24 object-contain" />
        <p class="mt-2 text-gray-700">Category 8</p>
    </div>
    <div class="flex flex-col items-center shadow-md rounded-md p-2">
        <img src="https://img.drz.lazcdn.com/static/bd/p/c400005c29cc708bc59a23034d9f8395.jpg_80x80q80.jpg_.webp"
            alt="Sample Image" class="w-full h-24 object-contain" />
        <p class="mt-2 text-gray-700">Category 8</p>
    </div>
    <div class="flex flex-col items-center shadow-md rounded-md p-2">
        <img src="https://img.drz.lazcdn.com/static/bd/p/c400005c29cc708bc59a23034d9f8395.jpg_80x80q80.jpg_.webp"
            alt="Sample Image" class="w-full h-24 object-contain" />
        <p class="mt-2 text-gray-700">Category 8</p>
    </div>
    <div class="flex flex-col items-center shadow-md rounded-md p-2">
        <img src="https://img.drz.lazcdn.com/static/bd/p/c400005c29cc708bc59a23034d9f8395.jpg_80x80q80.jpg_.webp"
            alt="Sample Image" class="w-full h-24 object-contain" />
        <p class="mt-2 text-gray-700">Category 8</p>
    </div>
    <div class="flex flex-col items-center shadow-md rounded-md p-2">
        <img src="https://img.drz.lazcdn.com/static/bd/p/c400005c29cc708bc59a23034d9f8395.jpg_80x80q80.jpg_.webp"
            alt="Sample Image" class="w-full h-24 object-contain" />
        <p class="mt-2 text-gray-700">Category 8</p>
    </div>
    <div class="flex flex-col items-center shadow-md rounded-md p-2">
        <img src="https://img.drz.lazcdn.com/static/bd/p/c400005c29cc708bc59a23034d9f8395.jpg_80x80q80.jpg_.webp"
            alt="Sample Image" class="w-full h-24 object-contain" />
        <p class="mt-2 text-gray-700">Category 8</p>
    </div>
</div><?php /**PATH F:\Laravel\project-name\resources\views/home/categories-slider.blade.php ENDPATH**/ ?>