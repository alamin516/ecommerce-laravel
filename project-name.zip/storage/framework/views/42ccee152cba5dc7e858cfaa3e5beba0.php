<div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 hidden md:block">
<div class="flex justify-end py-2">
  <div class="text-sm flex gap-10">
  <div>
  <a href="#" class="text-gray-500 hover:text-gray-700">Become a Seller</a>
  <span class="mx-4 text-gray-500">|</span>
  <a href="#" class="text-gray-500 hover:text-gray-700">Login to Seller</a>
  </div>
  <a href="#" class="text-gray-500 hover:text-gray-700">Helpline +880 1918-13880</a>
  </div>
</div>
</div><?php /**PATH F:\Laravel\project-name\resources\views/layouts/top-header.blade.php ENDPATH**/ ?>