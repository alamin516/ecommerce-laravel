

<?php $__env->startSection('content'); ?>
    <h1>Your Wishlist</h1>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.profile-layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\Laravel\project-name\resources\views/wishlists/wishlist.blade.php ENDPATH**/ ?>