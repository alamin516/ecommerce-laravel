

<?php $__env->startSection('content'); ?>
     <?php $__env->slot('heading', null, []); ?> 
        <h2 class="font-semibold text-xl text-gray-800 leading-tight">
            <?php echo e(__('Orders')); ?>

        </h2>
     <?php $__env->endSlot(); ?>

    <h1>Your Orders</h1>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.profile-layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\Laravel\project-name\resources\views/orders/orders.blade.php ENDPATH**/ ?>