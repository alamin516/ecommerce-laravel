<div :class="menu ? 'pl-64' : ''" class="text-center font-semibold text-gray-500 py-2 !mt-2 fixed bottom-0 left-0 z-[99] w-full">
    &copy; {{date('Y')}} AA. All rights reserved.
</div>