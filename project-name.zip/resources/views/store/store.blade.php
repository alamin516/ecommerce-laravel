<x-app-layout>
            <div class="max-w-7xl mx-auto min-h-[calc(100vh-66px)] flex justify-center items-center">
                <h1 class="text-gray-400 text-center text-3xl">Shop</h1>
            </div>
</x-app-layout>
