@extends('layouts.profile-layout')

@section('content')
    <h1>Settings</h1>
@endsection
