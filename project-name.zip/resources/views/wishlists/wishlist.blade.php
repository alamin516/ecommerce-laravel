@extends('layouts.profile-layout')

@section('content')
    <h1>Your Wishlist</h1>
@endsection
